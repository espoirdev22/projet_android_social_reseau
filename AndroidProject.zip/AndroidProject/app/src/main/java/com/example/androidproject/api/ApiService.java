package com.example.androidproject.api;

import com.example.androidproject.model.ApiResponse;
import com.example.androidproject.model.LoginRequest;
import com.example.androidproject.model.Utilisateur;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Body;

public interface ApiService {

    @POST("api/utilisateurs")
    Call<ApiResponse<Utilisateur>> registerUser(@Body Utilisateur utilisateur);

    @POST("api/utilisateurs/login")
    Call<ApiResponse<Utilisateur>> loginUser(@Body LoginRequest LoginRequest);

    @GET("api/utilisateurs")
    Call<ApiResponse<List<Utilisateur>>> getAllUser();

}
