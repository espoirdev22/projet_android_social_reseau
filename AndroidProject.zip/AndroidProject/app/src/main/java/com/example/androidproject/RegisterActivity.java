package com.example.androidproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.androidproject.api.ApiService;
import com.example.androidproject.api.RetrofitClient;
import com.example.androidproject.model.ApiResponse;
import com.example.androidproject.model.Utilisateur;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {
    private EditText prenomTxt;
    private EditText nomTxt;
    private EditText telephoneTxt;
    private EditText emailTxt;
    private EditText usernameTxt;
    private EditText passwordTxt;
    private EditText confirmPasswordTxt;
    private Button connexionBtn;
    private Button inscriptionBtn; // Correction ici

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initializeField();

        inscriptionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!testField()) return;

                // Récupérer les données
                String prenom = prenomTxt.getText().toString().trim();
                String nom = nomTxt.getText().toString().trim();
                String email = emailTxt.getText().toString().trim();
                String telephone = telephoneTxt.getText().toString().trim();
                String username = usernameTxt.getText().toString().trim();
                String password = passwordTxt.getText().toString().trim();

                // Créer l'objet RegisterRequest
                Utilisateur registerData = new Utilisateur(username, nom, prenom, telephone, password, email);

                // Appel API avec Retrofit
                ApiService apiService = RetrofitClient.getClient().create(ApiService.class);

                Call<ApiResponse<Utilisateur>> call = apiService.registerUser(registerData);

                call.enqueue(new Callback<ApiResponse<Utilisateur>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<Utilisateur>> call, Response<ApiResponse<Utilisateur>> response) {
                        if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                            Toast.makeText(RegisterActivity.this, "Inscription réussie", Toast.LENGTH_LONG).show();
                            // Rediriger vers la page de connexion
                            Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
                            i.putExtra("USERNAME", username);
                            startActivity(i);

                        } else {
                            Toast.makeText(RegisterActivity.this, response.body() != null ?
                                    response.body().getMessage() : "Erreur lors de l'inscription", Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<Utilisateur>> call, Throwable t) {
                        Log.e("RegisterError", "Erreur réseau", t);
                        Toast.makeText(RegisterActivity.this, "Erreur réseau", Toast.LENGTH_LONG).show();
                    }
                });
            }
        });


        connexionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!testField()){
                    return;
                }
                Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(i);
            }
        });
    }

    private void initializeField() {
        prenomTxt = findViewById(R.id.prenom_edt);
        nomTxt = findViewById(R.id.nom_edt);
        telephoneTxt = findViewById(R.id.tel_edt);
        emailTxt = findViewById(R.id.email_edt);
        usernameTxt = findViewById(R.id.username_edt);
        passwordTxt = findViewById(R.id.password_edt);
        confirmPasswordTxt = findViewById(R.id.confirm_password_edt);
        connexionBtn = findViewById(R.id.connexion_btn);
        inscriptionBtn = findViewById(R.id.inscription_btn);
    }

    private boolean testField() {
        String prenom = prenomTxt.getText().toString().trim();
        String nom = nomTxt.getText().toString().trim();
        String email = emailTxt.getText().toString().trim();
        String telephone = telephoneTxt.getText().toString().trim();
        String username = usernameTxt.getText().toString().trim();
        String password = passwordTxt.getText().toString().trim();
        String confirmPassword = confirmPasswordTxt.getText().toString().trim();

        if (prenom.isEmpty() || nom.isEmpty() || email.isEmpty() || telephone.isEmpty() ||
                username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(RegisterActivity.this, "Veuillez remplir tous les champs", Toast.LENGTH_LONG).show();
            return false;
        }

        if (password.length() < 8) {
            Toast.makeText(RegisterActivity.this, "Le mot de passe doit contenir au moins 8 caractères", Toast.LENGTH_LONG).show();
            return false;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(RegisterActivity.this, "Les mots de passe ne correspondent pas", Toast.LENGTH_LONG).show();
            return false;
        }

        return true;
    }
}
