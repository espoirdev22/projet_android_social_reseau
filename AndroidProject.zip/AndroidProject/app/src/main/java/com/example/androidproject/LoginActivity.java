package com.example.androidproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.androidproject.api.ApiService;
import com.example.androidproject.api.RetrofitClient;
import com.example.androidproject.model.ApiResponse;
import com.example.androidproject.model.LoginRequest;
import com.example.androidproject.model.Utilisateur;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameTxt;
    private EditText passwordTxt;
    private Button connexionBtn;
    private Button inscriptionBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initializeField();

        Intent i = getIntent();
        usernameTxt.setText(i.getStringExtra("USERNAME"));

        inscriptionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(i);
            }
        });

        connexionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameTxt.getText().toString().trim();
                String password = passwordTxt.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this,
                            "Veuillez remplir tous les champs",
                            Toast.LENGTH_LONG).show();
                } else {
                    LoginRequest dataUser = new LoginRequest(username, password);

                    ApiService apiService = RetrofitClient.getClient().create(ApiService.class);

                    Call<ApiResponse<Utilisateur>> call = apiService.loginUser(dataUser);

                    call.enqueue(new Callback<ApiResponse<Utilisateur>>() {
                        @Override
                        public void onResponse(Call<ApiResponse<Utilisateur>> call, Response<ApiResponse<Utilisateur>> response) {
                            if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                                Toast.makeText(LoginActivity.this, response.body().getMessage(), Toast.LENGTH_LONG).show();
                                usernameTxt.setText("");
                                passwordTxt.setText("");
                                startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                            } else {
                                Toast.makeText(LoginActivity.this, response.body().getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<ApiResponse<Utilisateur>> call, Throwable t) {
                            Toast.makeText(LoginActivity.this, "Erreur Reseau", Toast.LENGTH_LONG).show();
                        }
                    });

                }
            }
        });
    }

    private void initializeField() {

        usernameTxt = findViewById(R.id.username_edt);
        passwordTxt = findViewById(R.id.password_edt);

        connexionBtn = findViewById(R.id.connexion_btn);
        inscriptionBtn = findViewById(R.id.inscription_btn);
    }

}