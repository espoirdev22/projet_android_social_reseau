package com.example.androidproject;

import android.os.Bundle;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.androidproject.api.ApiService;
import com.example.androidproject.api.RetrofitClient;
import com.example.androidproject.model.ApiResponse;
import com.example.androidproject.model.Utilisateur;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity {

    TextView userTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        getSupportActionBar().hide();

        userTxt = findViewById(R.id.list_user);

        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);

        Call<ApiResponse<List<Utilisateur>>> call = apiService.getAllUser();

        call.enqueue(new Callback<ApiResponse<List<Utilisateur>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<Utilisateur>>> call, Response<ApiResponse<List<Utilisateur>>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().isSuccess()) {
                  List<Utilisateur> userList = response.body().getData();

                  StringBuilder strBuilder = new StringBuilder();

                  for (Utilisateur user : userList){

                      strBuilder.append("Prenom : ").append(user.getPrenom()).append("\n");
                      strBuilder.append("Nom : ").append(user.getNom()).append("\n");
                      strBuilder.append("Email : ").append(user.getEmail()).append("\n");
                      strBuilder.append("Tel : ").append(user.getTelephone()).append("\n");
                      strBuilder.append("Username : ").append(user.getPrenom()).append("\n");
                      strBuilder.append("\n---------------------------\n\n ").append(user.getPrenom()).append("\n");
                  }

                  String userStr = strBuilder.toString();
                  userTxt.setText(userStr);

                } else {
                    Toast.makeText(HomeActivity.this, response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<Utilisateur>>> call, Throwable t) {
                Toast.makeText(HomeActivity.this, "Erreur Reseau", Toast.LENGTH_LONG).show();
            }



        });
    }

}